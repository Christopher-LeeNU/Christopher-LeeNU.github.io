---
layout: page
title: Example Landing Page
subtitle: This is an example landing page with callouts
hero_height: is-large
hero_link: /page-1/
hero_link_text: Example Call To Action
show_sidebar: false
callouts: example_callouts
---

This is an example landing page. It is built using the Hero and Callouts.

[View the Hero docs](/bulma-clean-theme/docs/pages/hero/)

[View the Callouts docs](/bulma-clean-theme/docs/page-components/callouts/)
