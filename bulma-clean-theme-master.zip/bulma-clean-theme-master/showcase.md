---
title: Showcase
subtitle: An example showcase page
description: An example showcase page to help you easily display your work
layout: page
showcase: showcase_example
show_sidebar: false
---

[View the showcase docs](/bulma-clean-theme/docs/page-components/showcases/)
